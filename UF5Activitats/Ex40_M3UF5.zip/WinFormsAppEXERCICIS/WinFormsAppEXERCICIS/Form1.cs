namespace WinFormsAppEXERCICIS
{
    public partial class form : System.Windows.Forms.Form
    {
        public form()
        {
            InitializeComponent();
        }

        private string CalcularPromedio()
        {
            int numberOfNotes = 4;
            double average = (Convert.ToInt32(textNota1.Text) +
                              Convert.ToInt32(textNota2.Text) +
                              Convert.ToInt32(textNota3.Text) +
                              Convert.ToInt32(textNota4.Text))
                              / numberOfNotes;
            return average.ToString();
        }

        private string NotaMinima()
        {
            double[] array = [Convert.ToDouble(textNota1.Text),
                Convert.ToDouble(textNota2.Text),
                Convert.ToDouble(textNota3.Text),
                Convert.ToDouble(textNota4.Text)];

            double min = array.Min();

            return min.ToString();
        }

        private string CondicionNota()
        {
            const string MsgAprobado = "Aprobado";
            const string MsgSuspenso = "Suspenso";

            double promedio = Convert.ToDouble(CalcularPromedio());

            return promedio >= 5 ? MsgAprobado : MsgSuspenso;
        }
        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                labelResultadoMediaNotas.Text = CalcularPromedio();
                labelResultadoNotaBaja.Text = NotaMinima();
                labelResultadoCondicion.Text = CondicionNota();
            }
            
        }

        private void buttonLimpiar_Click(object sender, EventArgs e)
        {
            textNombre.Text = string.Empty;
            textNota1.Text = string.Empty;
            textNota2.Text = string.Empty;
            textNota3.Text = string.Empty;
            textNota4.Text = string.Empty;
            labelResultadoMediaNotas.Text = "-";
            labelResultadoNotaBaja.Text = "-";
            labelResultadoCondicion.Text = "-";
        }

        private void buttonSortir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textNombre_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textNombre.Text))
            {
                errorNombre.SetError(textNombre, "El nombre no puede estar vac�o");
                e.Cancel = true;
            }
            else if (HasNumbers(textNombre.Text))
            {
                errorNombre.SetError(textNombre, "El nombre no puede contener n�meros");
                e.Cancel = true;
            }
            else
            {
                errorNombre.SetError(textNombre, string.Empty);
                e.Cancel = false;
            }
        }

        private bool HasNumbers(string text)
        {
            foreach (char c in text)
            {
                if (char.IsDigit(c))
                {
                    return true;
                }
            }
            return false;
        }

        private void textNotas_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            if (string.IsNullOrEmpty(textBox.Text))
            {
                errorNotas.SetError(textBox, "La nota no puede estar vac�a");
                e.Cancel = true;
            }
            else if (!textBox.Text.All(char.IsDigit))
            {
                errorNotas.SetError(textBox, "La nota debe de ser un n�mero");
                e.Cancel = true;
            }
            else if (Convert.ToInt32(textBox.Text) < 0 || Convert.ToInt32(textBox.Text) > 10)
            {
                errorNotas.SetError(textBox, "La nota debe de estar entre 0 y 10");
                e.Cancel = true;
            }
            else
            {
                errorNotas.SetError(textBox, string.Empty);
                e.Cancel = false;
            }
            
        }

    }
}
