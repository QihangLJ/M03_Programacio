﻿namespace WinFormsAppEXERCICIS
{
    partial class form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            title = new Label();
            textNota4 = new TextBox();
            textNota1 = new TextBox();
            textNota2 = new TextBox();
            textNota3 = new TextBox();
            textNombre = new TextBox();
            labelNombre = new Label();
            labelNota1 = new Label();
            labelNota2 = new Label();
            labelNota3 = new Label();
            labelNota4 = new Label();
            labelMediaNotas = new Label();
            labelNotaBaja = new Label();
            labelCondicion = new Label();
            labelResultadoMediaNotas = new Label();
            labelResultadoNotaBaja = new Label();
            labelResultadoCondicion = new Label();
            groupBoxNotas = new GroupBox();
            comboBox4 = new ComboBox();
            comboBox3 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            buttonCalcular = new Button();
            buttonLimpiar = new Button();
            buttonSalir = new Button();
            errorNotas = new ErrorProvider(components);
            errorNombre = new ErrorProvider(components);
            errorModul = new ErrorProvider(components);
            groupBoxNotas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorNotas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorNombre).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorModul).BeginInit();
            SuspendLayout();
            // 
            // title
            // 
            title.AutoSize = true;
            title.Font = new Font("Segoe UI", 20F);
            title.Location = new Point(121, 19);
            title.Name = "title";
            title.Size = new Size(447, 37);
            title.TabIndex = 0;
            title.Text = "CONTROL DE PROMEDIO DE NOTAS";
            // 
            // textNota4
            // 
            textNota4.Location = new Point(279, 103);
            textNota4.Name = "textNota4";
            textNota4.Size = new Size(67, 32);
            textNota4.TabIndex = 1;
            textNota4.Validating += textNotas_Validating;
            // 
            // textNota1
            // 
            textNota1.Location = new Point(14, 103);
            textNota1.Name = "textNota1";
            textNota1.Size = new Size(67, 32);
            textNota1.TabIndex = 2;
            textNota1.Validating += textNotas_Validating;
            // 
            // textNota2
            // 
            textNota2.Location = new Point(103, 103);
            textNota2.Name = "textNota2";
            textNota2.Size = new Size(67, 32);
            textNota2.TabIndex = 4;
            textNota2.Validating += textNotas_Validating;
            // 
            // textNota3
            // 
            textNota3.Location = new Point(192, 103);
            textNota3.Name = "textNota3";
            textNota3.Size = new Size(67, 32);
            textNota3.TabIndex = 3;
            textNota3.Validating += textNotas_Validating;
            // 
            // textNombre
            // 
            textNombre.Location = new Point(44, 120);
            textNombre.Name = "textNombre";
            textNombre.Size = new Size(199, 23);
            textNombre.TabIndex = 6;
            textNombre.Validating += textNombre_Validating;
            // 
            // labelNombre
            // 
            labelNombre.AutoSize = true;
            labelNombre.Font = new Font("Segoe UI", 14F);
            labelNombre.Location = new Point(44, 83);
            labelNombre.Name = "labelNombre";
            labelNombre.Size = new Size(154, 25);
            labelNombre.TabIndex = 7;
            labelNombre.Text = "Nombre alumno:";
            // 
            // labelNota1
            // 
            labelNota1.AutoSize = true;
            labelNota1.Font = new Font("Segoe UI", 12F);
            labelNota1.Location = new Point(14, 37);
            labelNota1.Name = "labelNota1";
            labelNota1.Size = new Size(59, 21);
            labelNota1.TabIndex = 9;
            labelNota1.Text = "NOTA1";
            // 
            // labelNota2
            // 
            labelNota2.AutoSize = true;
            labelNota2.Font = new Font("Segoe UI", 12F);
            labelNota2.Location = new Point(103, 37);
            labelNota2.Name = "labelNota2";
            labelNota2.Size = new Size(59, 21);
            labelNota2.TabIndex = 10;
            labelNota2.Text = "NOTA2";
            // 
            // labelNota3
            // 
            labelNota3.AutoSize = true;
            labelNota3.Font = new Font("Segoe UI", 12F);
            labelNota3.Location = new Point(192, 37);
            labelNota3.Name = "labelNota3";
            labelNota3.Size = new Size(59, 21);
            labelNota3.TabIndex = 11;
            labelNota3.Text = "NOTA3";
            // 
            // labelNota4
            // 
            labelNota4.AutoSize = true;
            labelNota4.Font = new Font("Segoe UI", 12F);
            labelNota4.Location = new Point(279, 37);
            labelNota4.Name = "labelNota4";
            labelNota4.Size = new Size(59, 21);
            labelNota4.TabIndex = 12;
            labelNota4.Text = "NOTA4";
            // 
            // labelMediaNotas
            // 
            labelMediaNotas.AutoSize = true;
            labelMediaNotas.Font = new Font("Segoe UI", 12F);
            labelMediaNotas.Location = new Point(44, 222);
            labelMediaNotas.Name = "labelMediaNotas";
            labelMediaNotas.Size = new Size(169, 21);
            labelMediaNotas.TabIndex = 13;
            labelMediaNotas.Text = "PROMEDIO DE NOTAS:";
            // 
            // labelNotaBaja
            // 
            labelNotaBaja.AutoSize = true;
            labelNotaBaja.Font = new Font("Segoe UI", 12F);
            labelNotaBaja.Location = new Point(83, 260);
            labelNotaBaja.Name = "labelNotaBaja";
            labelNotaBaja.Size = new Size(130, 21);
            labelNotaBaja.TabIndex = 14;
            labelNotaBaja.Text = "NOTA MÁS BAJA:";
            // 
            // labelCondicion
            // 
            labelCondicion.AutoSize = true;
            labelCondicion.Font = new Font("Segoe UI", 12F);
            labelCondicion.Location = new Point(113, 297);
            labelCondicion.Name = "labelCondicion";
            labelCondicion.Size = new Size(100, 21);
            labelCondicion.TabIndex = 15;
            labelCondicion.Text = "CONDICION:";
            // 
            // labelResultadoMediaNotas
            // 
            labelResultadoMediaNotas.AutoSize = true;
            labelResultadoMediaNotas.Font = new Font("Segoe UI", 12F);
            labelResultadoMediaNotas.Location = new Point(228, 222);
            labelResultadoMediaNotas.Name = "labelResultadoMediaNotas";
            labelResultadoMediaNotas.Size = new Size(16, 21);
            labelResultadoMediaNotas.TabIndex = 16;
            labelResultadoMediaNotas.Text = "-";
            // 
            // labelResultadoNotaBaja
            // 
            labelResultadoNotaBaja.AutoSize = true;
            labelResultadoNotaBaja.Font = new Font("Segoe UI", 12F);
            labelResultadoNotaBaja.Location = new Point(228, 260);
            labelResultadoNotaBaja.Name = "labelResultadoNotaBaja";
            labelResultadoNotaBaja.Size = new Size(16, 21);
            labelResultadoNotaBaja.TabIndex = 17;
            labelResultadoNotaBaja.Text = "-";
            // 
            // labelResultadoCondicion
            // 
            labelResultadoCondicion.AutoSize = true;
            labelResultadoCondicion.Font = new Font("Segoe UI", 12F);
            labelResultadoCondicion.Location = new Point(228, 297);
            labelResultadoCondicion.Name = "labelResultadoCondicion";
            labelResultadoCondicion.Size = new Size(16, 21);
            labelResultadoCondicion.TabIndex = 18;
            labelResultadoCondicion.Text = "-";
            // 
            // groupBoxNotas
            // 
            groupBoxNotas.Controls.Add(comboBox4);
            groupBoxNotas.Controls.Add(comboBox3);
            groupBoxNotas.Controls.Add(comboBox2);
            groupBoxNotas.Controls.Add(comboBox1);
            groupBoxNotas.Controls.Add(textNota2);
            groupBoxNotas.Controls.Add(textNota4);
            groupBoxNotas.Controls.Add(textNota1);
            groupBoxNotas.Controls.Add(textNota3);
            groupBoxNotas.Controls.Add(labelNota1);
            groupBoxNotas.Controls.Add(labelNota2);
            groupBoxNotas.Controls.Add(labelNota3);
            groupBoxNotas.Controls.Add(labelNota4);
            groupBoxNotas.Font = new Font("Segoe UI", 14F);
            groupBoxNotas.Location = new Point(288, 83);
            groupBoxNotas.Name = "groupBoxNotas";
            groupBoxNotas.Size = new Size(363, 160);
            groupBoxNotas.TabIndex = 19;
            groupBoxNotas.TabStop = false;
            groupBoxNotas.Text = "Registro notas:";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M11", "M15", "M16" });
            comboBox4.Location = new Point(279, 64);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(67, 33);
            comboBox4.TabIndex = 26;
            comboBox4.Validating += comboBox_Validating;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M11", "M15", "M16" });
            comboBox3.Location = new Point(192, 64);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(67, 33);
            comboBox3.TabIndex = 25;
            comboBox3.Validating += comboBox_Validating;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M11", "M15", "M16" });
            comboBox2.Location = new Point(103, 64);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(67, 33);
            comboBox2.TabIndex = 24;
            comboBox2.Validating += comboBox_Validating;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M11", "M15", "M16" });
            comboBox1.Location = new Point(14, 64);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(67, 33);
            comboBox1.TabIndex = 23;
            comboBox1.Validating += comboBox_Validating;
            // 
            // buttonCalcular
            // 
            buttonCalcular.Location = new Point(44, 160);
            buttonCalcular.Name = "buttonCalcular";
            buttonCalcular.Size = new Size(89, 39);
            buttonCalcular.TabIndex = 20;
            buttonCalcular.Text = "CALCULAR";
            buttonCalcular.UseVisualStyleBackColor = true;
            buttonCalcular.Click += buttonCalcular_Click;
            // 
            // buttonLimpiar
            // 
            buttonLimpiar.Location = new Point(155, 160);
            buttonLimpiar.Name = "buttonLimpiar";
            buttonLimpiar.Size = new Size(89, 39);
            buttonLimpiar.TabIndex = 21;
            buttonLimpiar.Text = "LIMPIAR";
            buttonLimpiar.UseVisualStyleBackColor = true;
            buttonLimpiar.Click += buttonLimpiar_Click;
            // 
            // buttonSalir
            // 
            buttonSalir.Location = new Point(562, 290);
            buttonSalir.Name = "buttonSalir";
            buttonSalir.Size = new Size(89, 39);
            buttonSalir.TabIndex = 22;
            buttonSalir.Text = "SALIR";
            buttonSalir.UseVisualStyleBackColor = true;
            buttonSalir.Click += buttonSortir_Click;
            // 
            // errorNotas
            // 
            errorNotas.ContainerControl = this;
            // 
            // errorNombre
            // 
            errorNombre.ContainerControl = this;
            // 
            // errorModul
            // 
            errorModul.ContainerControl = this;
            // 
            // form
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.Disable;
            ClientSize = new Size(704, 352);
            Controls.Add(buttonSalir);
            Controls.Add(buttonLimpiar);
            Controls.Add(buttonCalcular);
            Controls.Add(groupBoxNotas);
            Controls.Add(labelResultadoCondicion);
            Controls.Add(labelResultadoNotaBaja);
            Controls.Add(labelResultadoMediaNotas);
            Controls.Add(labelCondicion);
            Controls.Add(labelNotaBaja);
            Controls.Add(labelMediaNotas);
            Controls.Add(labelNombre);
            Controls.Add(textNombre);
            Controls.Add(title);
            Name = "form";
            Text = "Control de promedio de notas";
            groupBoxNotas.ResumeLayout(false);
            groupBoxNotas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorNotas).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorNombre).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorModul).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label title;
        private TextBox textNota4;
        private TextBox textNota1;
        private TextBox textNota2;
        private TextBox textNota3;
        private TextBox textNombre;
        private Label labelNombre;
        private Label labelNota1;
        private Label labelNota2;
        private Label labelNota3;
        private Label labelNota4;
        private Label labelMediaNotas;
        private Label labelNotaBaja;
        private Label labelCondicion;
        private Label labelResultadoMediaNotas;
        private Label labelResultadoNotaBaja;
        private Label labelResultadoCondicion;
        private GroupBox groupBoxNotas;
        private Button buttonCalcular;
        private Button buttonLimpiar;
        private Button buttonSalir;
        private ErrorProvider errorNotas;
        private ErrorProvider errorNombre;
        private ComboBox comboBox4;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private ErrorProvider errorModul;
    }
}
